module com {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires lombok;
    requires mysql.connector.j;
    requires java.sql;
    requires org.hibernate.orm.core;
    requires jakarta.persistence;
    requires java.naming;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;

    opens com to javafx.fxml, javafx.graphics;
    exports com to javafx.fxml, javafx.graphics;
    opens com.fxControllers to javafx.fxml;
    exports com.fxControllers to javafx.fxml;
    opens com.fxControllers.tableParameters to javafx.fxml;
    exports com.fxControllers.tableParameters to javafx.fxml;
    opens com.model to javafx.fxml, org.hibernate.orm.core, jakarta.persistence, java.base;
    exports com.model to javafx.fxml, org.hibernate.orm.core, jakarta.persistence, java.base;
}