package com.fxControllers;
import com.HelloApplication;
import com.hibernate.ShopHibernate;
import com.model.Customer;
import com.model.Manager;
import com.model.User;

import jakarta.persistence.EntityManagerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
public class registrationWindow {

    @FXML
    private TextField addressField;

    @FXML
    private TextField billingAddressField;

    @FXML
    private DatePicker birthDateField;

    @FXML
    private RadioButton customerCheckbox;

    @FXML
    private CheckBox isAdminCheck;

    @FXML
    private TextField loginField;

    @FXML
    private TextField nameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField repeatPasswordField;

    @FXML
    private TextField surnameField;

    @FXML
    private ToggleGroup userType;
    @FXML
    public RadioButton managerCheckbox;
    @FXML
    public TextField employeeIdField;
    @FXML
    public TextField emailField;

    private EntityManagerFactory entityManagerFactory;

    public void setData(EntityManagerFactory entityManagerFactory, boolean showManagerFields) {
        this.entityManagerFactory = entityManagerFactory;
        disableFields(showManagerFields);
    }

    public void setData(EntityManagerFactory entityManagerFactory, Manager manager) {
        this.entityManagerFactory = entityManagerFactory;
        toggleFields(customerCheckbox.isSelected(), manager);
    }

    private void disableFields(boolean showManagerFields) {
        if (!showManagerFields) {
            employeeIdField.setVisible(false);
            isAdminCheck.setVisible(false);
            managerCheckbox.setVisible(false);
        }
    }

    private void toggleFields(boolean isManager, Manager manager) {
        if (isManager) {
            addressField.setDisable(true);
            employeeIdField.setDisable(false);
            if (manager.isAdmin()) isAdminCheck.setDisable(false);
        } else {
            addressField.setDisable(false);
            employeeIdField.setDisable(true);
            isAdminCheck.setDisable(true);
        }
    }


    public void createUser() {
        ShopHibernate shopHibernate = new ShopHibernate(entityManagerFactory);
        if (customerCheckbox.isSelected()) {
            User user = new Customer(nameField.getText(), surnameField.getText(), loginField.getText(), passwordField.getText(), addressField.getText(), billingAddressField.getText(), birthDateField.getValue(), emailField.getText());
            shopHibernate.create(user);
        } else {
            //Create Manager
        }
    }

    public void returnToLogin() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login-form.fxml"));
        Parent parent = fxmlLoader.load();
        Stage stage = (Stage) loginField.getScene().getWindow();
        Scene scene = new Scene(parent);
        fxUtils.setStageParameters(stage, scene, false);
    }
}

