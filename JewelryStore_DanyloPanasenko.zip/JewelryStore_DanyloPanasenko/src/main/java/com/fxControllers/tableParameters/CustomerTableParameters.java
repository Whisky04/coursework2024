package com.fxControllers.tableParameters;

public class CustomerTableParameters extends UserTableParameters{
    //TODO complete based on UserTableParameters, customer unique attributes
}
