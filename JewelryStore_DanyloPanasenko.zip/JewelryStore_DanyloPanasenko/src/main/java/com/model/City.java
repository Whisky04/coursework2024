package com.model;

public enum City {
    KLAIPEDA, VILNIUS, KAUNAS, PANEVEZYS, SIAULIAI
}
