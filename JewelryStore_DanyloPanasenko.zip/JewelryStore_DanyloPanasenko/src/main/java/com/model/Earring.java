package com.model;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Earring extends Product {
    private EarringType earringType;

    public Earring(String title, String description, int quantity, String colour, String material, EarringType earringType) {
        super(title, description, quantity, colour, material);
        this.earringType = earringType;
    }
}