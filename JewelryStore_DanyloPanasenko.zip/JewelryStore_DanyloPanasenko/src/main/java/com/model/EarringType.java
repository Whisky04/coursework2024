package com.model;

public enum EarringType {
    STUD, JACKET, EAR_SPIKE, PLUG, HUGGIE
}
